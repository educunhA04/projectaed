#ifndef PROJETO_STUDENT_H
#define PROJETO_STUDENT_H
#include <iostream>
#include <string>
#include <vector>

class Student{
    private:
        string name;
        string studentCode;
        vector<Classes> schedule;

    public:
        Student(const string& newName, const string& newStudentCode, const string& newSchedule){
            this->name = newName;
            this->studentCode = newStudentCode;
            this->schedule = newSchedule;
        }
        string getName(){return name;}
        string getStudentCode(){return studentCode;}
        vector<Classes> getSchedule(){return schedule;}
};

#endif //PROJETO_STUDENT_H
