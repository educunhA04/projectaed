#ifndef PROJETO_CLASSES_H
#define PROJETO_CLASSES_H
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Classes{
    private:
        string classCode;       // ex: 1LEIC01                             //
        string ucCode;          // ex: L.EIC001                            //
        string weekday;         // Monday, Saturday etc.                   //
        double duration;        // horas convertidas ex 1:30h -> 1.5       //
        double startHour;       // hora a que começa formato 10:30 -> 10.5 //
        string typeOfClass;     // T / TP / PL                             //

    public:
        Classes(const string& cCode, const string& uCode, const string& day, double dur, double sHour, const string& classType) {
            this->classCode = cCode;
            this->ucCode = uCode;
            this->weekday = day;
            this->duration = dur;
            this->startHour = sHour;
            this->typeOfClass = classType;
        }

        string getClassCode() const {return classCode;}
        string getUcCode() const {return ucCode;}
        string getWeekDay() const {return weekday;}
        double getDuration() const {return duration;}
        double getStartHour() const {return startHour;}
        string getTypeOfClass() const {return typeOfClass;}
        double getEndHour() const {return startHour + duration;}


};
#endif //PROJETO_CLASSES_H
